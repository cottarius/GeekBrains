package view;

import model.Model;

public class View {
    public void print(int result){
        System.out.printf("Result: %s\n", result);
    }
}
